﻿
   ▄████████  ▄█    ▄▄▄▄███▄▄▄▄      ▄███████▄  ▄█        ▄█     ▄████████     ███      ▄█   ▄████████  ▄██████▄  
  ███    ███ ███  ▄██▀▀▀███▀▀▀██▄   ███    ███ ███       ███    ███    ███ ▀█████████▄ ███  ███    ███ ███    ███ 
  ███    █▀  ███▌ ███   ███   ███   ███    ███ ███       ███▌   ███    █▀     ▀███▀▀██ ███▌ ███    █▀  ███    ███ 
  ███        ███▌ ███   ███   ███   ███    ███ ███       ███▌   ███            ███   ▀ ███▌ ███        ███    ███ 
▀███████████ ███▌ ███   ███   ███ ▀█████████▀  ███       ███▌ ▀███████████     ███     ███▌ ███        ███    ███ 
         ███ ███  ███   ███   ███   ███        ███       ███           ███     ███     ███  ███    █▄  ███    ███
   ▄█    ███ ███  ███   ███   ███   ███        ███▌    ▄ ███     ▄█    ███     ███     ███  ███    ███ ███    ███ 
 ▄████████▀  █▀    ▀█   ███   █▀   ▄████▀      █████▄▄██ █▀    ▄████████▀     ▄████▀   █▀   ████████▀   ▀██████▀  

 ______  __   __      _______  _____  _______  _____  _______  ______
 |_____]   \_/        |       |     | |  |  | |_____] |______ |_____/
 |_____]    |         |_____  |_____| |  |  | |       |______ |    \_
                                                                     
Thank you for downloading and using my resourcepack!

to install drag this .zip in your Minecraft Resourcepack-Folder



 

                          

Do not reupload this Resourcepack.
You are permitted use the “Compers GUI-Pack” as a server-pack for your server if you credit me visible on the server.

If you have any open questions, go ahead and ask me via pmc.



credits: http://www.planetminecraft.com/member/comper/
